let param = new URLSearchParams(location.search);
var token = param.get('IVAOTOKEN');
let userInfo = [];

if(token != null){
    fetch(`./getUser/${token}`)
    .then(data => data.json())
    .then(data => {
        userInfo = data;
        console.log(userInfo);
    })}